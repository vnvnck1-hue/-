import { Entity } from "./Entity";
import type { GameState } from "../core/GameState";
import type { EnemyKind, Vec2 } from "../core/Types";
import {
  COLORS,
  BATTLE_TOP,
  BATTLE_BOTTOM,
  BATTLE_LEFT,
  BATTLE_RIGHT,
} from "../core/Types";
import { Projectile } from "./Projectile";
import { DamageText } from "../effects/DamageText";
import type { Hero } from "./Hero";

export interface EnemyConfig {
  kind: EnemyKind;
  hp: number;
  atk: number;
  atkSpd: number;
  attackRange: number;
  preferredDistance: number;
  moveSpeed: number;
  color: string;
  radius: number;
  /** 처치 시 골드 드랍 양 */
  gold: number;
  /** 아이템 드랍 확률 */
  itemDropChance: number;
}

const CONFIGS: Record<EnemyKind, EnemyConfig> = {
  goblin: {
    kind: "goblin",
    hp: 35,
    atk: 6,
    atkSpd: 2.0,
    attackRange: 22,
    preferredDistance: 0,
    moveSpeed: 110,
    color: COLORS.enemy,
    radius: 10,
    gold: 3,
    itemDropChance: 0.18,
  },
  goblinArcher: {
    kind: "goblinArcher",
    hp: 28,
    atk: 7,
    atkSpd: 1.6,
    attackRange: 140,
    preferredDistance: 110,
    moveSpeed: 100,
    color: COLORS.enemyArcher,
    radius: 9,
    gold: 4,
    itemDropChance: 0.25,
  },
  orc: {
    kind: "orc",
    hp: 110,
    atk: 11,
    atkSpd: 1.4,
    attackRange: 26,
    preferredDistance: 0,
    moveSpeed: 76,
    color: COLORS.enemyTank,
    radius: 14,
    gold: 10,
    itemDropChance: 0.55,
  },
};

export class Enemy extends Entity {
  readonly kind: EnemyKind;
  readonly cfg: EnemyConfig;
  attackCooldown = 0;
  /** 스포너에서 부여하는 체력/공격력 스케일 */
  scale: number;

  constructor(kind: EnemyKind, pos: Vec2, scale = 1) {
    const cfg = CONFIGS[kind];
    super("enemy", pos, Math.round(cfg.hp * scale));
    this.kind = kind;
    this.cfg = cfg;
    this.scale = scale;
    this.radius = cfg.radius;
  }

  override update(dt: number, state: GameState): void {
    this.baseUpdate(dt);
    if (!this.alive) return;

    const target = this.findHeroTarget(state);
    this.attackCooldown -= dt;

    if (target) {
      const dx = target.pos.x - this.pos.x;
      const dy = target.pos.y - this.pos.y;
      const d = Math.hypot(dx, dy) || 1;
      const desired = this.cfg.preferredDistance;

      if (this.cfg.kind === "goblinArcher") {
        if (d < desired - 6) {
          this.vel.x = -(dx / d) * this.cfg.moveSpeed;
          this.vel.y = -(dy / d) * this.cfg.moveSpeed * 0.6;
        } else if (d > desired + 6) {
          this.vel.x = (dx / d) * this.cfg.moveSpeed * 0.7;
          this.vel.y = (dy / d) * this.cfg.moveSpeed * 0.7;
        }
      } else {
        if (d > this.cfg.attackRange - 2) {
          this.vel.x = (dx / d) * this.cfg.moveSpeed;
          this.vel.y = (dy / d) * this.cfg.moveSpeed;
        }
      }

      // 공격
      if (this.attackCooldown <= 0 && d <= this.cfg.attackRange + 2) {
        this.attackCooldown = 1 / this.cfg.atkSpd;
        this.attack(target, state);
      }
    }

    this.pos.x += (this.vel.x + this.knockback.x) * dt;
    this.pos.y += (this.vel.y + this.knockback.y) * dt;
    this.pos.x = Math.max(BATTLE_LEFT, Math.min(BATTLE_RIGHT, this.pos.x));
    this.pos.y = Math.max(BATTLE_TOP + 8, Math.min(BATTLE_BOTTOM - 8, this.pos.y));
    this.vel.x = 0;
    this.vel.y = 0;
  }

  private findHeroTarget(state: GameState): Hero | null {
    let best: Hero | null = null;
    let bestD = Infinity;
    for (const h of state.heroes) {
      if (!h.alive) continue;
      const d = Math.hypot(h.pos.x - this.pos.x, h.pos.y - this.pos.y);
      if (d < bestD) {
        bestD = d;
        best = h;
      }
    }
    return best;
  }

  private attack(target: Hero, state: GameState): void {
    const dmg = Math.round(this.cfg.atk * this.scale);
    if (this.cfg.kind === "goblinArcher") {
      const a = Math.atan2(target.pos.y - this.pos.y, target.pos.x - this.pos.x);
      state.projectiles.push(
        new Projectile({
          pos: { ...this.pos },
          angle: a,
          speed: 400,
          damage: dmg,
          isCrit: false,
          faction: "enemy",
          color: "#ffb56a",
          radius: 3,
          kind: "arrow",
          ownerId: this.id,
          lifetime: 1.6,
        })
      );
    } else {
      const dir = { x: target.pos.x - this.pos.x, y: target.pos.y - this.pos.y };
      target.takeDamage(dmg, dir);
      state.effects.push(new DamageText(target.pos, dmg, "incoming"));
      state.camera.shake(1.5, 0.1);
    }
  }

  override draw(ctx: CanvasRenderingContext2D): void {
    if (!this.alive) return;
    const sq = this.squash;
    const sx = 1 + (sq - 1);
    const sy = 1 - (sq - 1) * 0.5;

    ctx.save();
    ctx.translate(this.pos.x, this.pos.y);
    ctx.scale(sx, sy);

    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.beginPath();
    ctx.ellipse(0, this.radius * 0.85, this.radius * 0.8, this.radius * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();

    // 본체
    ctx.fillStyle = this.cfg.color;
    if (this.kind === "orc") {
      // 사각형 탱커
      ctx.fillRect(-this.radius, -this.radius, this.radius * 2, this.radius * 2);
      ctx.strokeStyle = "rgba(0,0,0,0.45)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(-this.radius, -this.radius, this.radius * 2, this.radius * 2);
    } else {
      ctx.beginPath();
      ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(0,0,0,0.45)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    // 표식
    ctx.fillStyle = "#fff";
    ctx.font = "bold 9px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const mark = this.kind === "goblin" ? "G" : this.kind === "goblinArcher" ? "A" : "O";
    ctx.fillText(mark, 0, 0);

    if (this.hitFlash > 0) {
      ctx.globalCompositeOperation = "lighter";
      ctx.fillStyle = `rgba(255,255,255,${this.hitFlash * 0.7})`;
      ctx.beginPath();
      ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // HP 바
    const bw = 22;
    const bh = 3;
    const bx = this.pos.x - bw / 2;
    const by = this.pos.y - this.radius - 7;
    const hpRatio = this.hp / this.maxHp;
    if (hpRatio < 1) {
      ctx.fillStyle = "rgba(0,0,0,0.55)";
      ctx.fillRect(bx, by, bw, bh);
      ctx.fillStyle = "#ff5050";
      ctx.fillRect(bx, by, bw * hpRatio, bh);
    }
  }
}
